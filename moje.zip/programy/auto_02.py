#!/usr/bin/env python3
import pyglet
from pyglet.window import key

"""
verze 02

- přidává obsluhu události 'on_key_press' - stisk klávesy
- jednotlivé klávesy jsou 'key.KLAVESA'
 
    key.RIGHT   - nastaví pohyb vpravo po ose x
    key.LEFT    - nastaví pohyb vlevo po ose x
    key.PLUS    - zvyšuje rychlost 
    key.MINUS   - snižuje rychlost 

"""
def tik(t):
    """ obsluha 'clock tick' - běh hodin """
    auto.x += v*t*smer_x

def klik(x, y, tlacitko, mod):
    """ obsluha 'on_mouse_press' - klik myší """
    auto.x = x
    auto.y = y    

def vykresli():
    """ obsluha 'on_draw' - vykreslení celé scény """
    window.clear()
    auto.draw()

def klavesa(klavesa, mod):
    """ obsluha 'on_key_press' - stisk klávesy """
    global smer_x, v
    if klavesa == key.D:
        smer_x = 1
    elif klavesa == key.A:
        smer_x = -1
    elif klavesa == key.W:
        v += v_delta
    elif klavesa == key.D:        
        v -= v_delta

"""
popis proměnných:
    v       - aktuální rychlost posunu obrázku po scéně
    v_delta - velikost změny rychlosti
    smer_x  - směr pohybu po ose x (+1 - vpravo, -1 - vlevo)
"""
v = 50
v_delta = 100
smer_x = 1

# -- vytvoření objektu okna aplikace
window = pyglet.window.Window(width=1200, height=900)

# -- vytvoření 'sprite' - objektu obrázku
obrazek_auto = pyglet.image.load('auto1.png')
auto = pyglet.sprite.Sprite(obrazek_auto)

# -- registrování oblužných funkcí k příslušným událostem
window.push_handlers(
    on_draw=vykresli,
    on_mouse_press=klik,
    on_key_press=klavesa
)

# -- registrace funkce pro obsluhu 'běhu času'
pyglet.clock.schedule_interval(tik, 1/30)

# -- spuštění aplikace
pyglet.app.run()
