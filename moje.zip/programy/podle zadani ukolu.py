#!/usr/bin/env python3
import pyglet
from pyglet.window import key
from pyglet.window import mouse




def tik(t):
    if smer_x != 0:
        auto.x = auto.x + v*t * smer_x

    # -- obrázek mimo okno aplikace
    if auto.x > window.width:
        auto.x = -auto.width
    if auto.x+auto.width < 0:
        auto.x = window.width

def zpracuj_klavesu(klavesa, mod):
    global smer_x, v, smer_vpravo
 
    if klavesa == key.D:
        smer_x = 1
        smer_vpravo = True
        auto.image = obrazek_vpravo
    elif klavesa == key.A:
        smer_x = -1
        smer_vpravo = False
        auto.image = obrazek_vlevo
    elif klavesa == key.W:
            v = v + v_delta
    elif klavesa == key.S:
            v = v - v_delta
    elif klavesa == key.R:
        smer_x = 1
        v = 0
        smer_vpravo = True
        auto.image = obrazek_vpravo
        auto.x = 800

def klik(x, y, tlacitko, mod):
    auto.x = x    

def vykresli():
    window.clear()
    pozadi.draw()
    auto.draw()


def zmen_obrazek(t):
    if smer_vpravo:
        auto.image = obrazek_vpravo_2
    else:
        auto.image = obrazek_vlevo_2
    pyglet.clock.schedule_once(zmen_obrazek_zpet, 0.2)

def zmen_obrazek_zpet(t):
    if smer_vpravo:
        auto.image = obrazek_vpravo
    else:
        auto.image = obrazek_vlevo
    pyglet.clock.schedule_once(zmen_obrazek, 0.2)

# -- nastavení proměnných
smer_x = 1          # směr vpravo pro výpočet rychlosti
v = 0              # počáteční rychlost auta
v_delta = 10        # přírůstek rychlosti auta
smer_vpravo = True  # směr auta pro animaci

window = pyglet.window.Window(width=1800, height=800)

# -- příprava všech variant obrázků
obrazek_vpravo   = pyglet.image.load('auto2_vpravo.png')
obrazek_vlevo    = pyglet.image.load('auto2_vlevo.png')
obrazek_vpravo_2 = pyglet.image.load('auto2_vpravo_2.png')
obrazek_vlevo_2  = pyglet.image.load('auto2_vlevo_2.png')

# -- vytvoření spritu
auto = pyglet.sprite.Sprite(obrazek_vpravo, x=800, y=10)
pozadi = pyglet.sprite.Sprite(pyglet.image.load('bg6.png'))

# -- registrace ovladačů událostí
window.push_handlers(
    on_key_press=zpracuj_klavesu,
    on_draw=vykresli,
    on_mouse_press=klik,
)

# -- ovladač časového intervalu
pyglet.clock.schedule_interval(tik, 1/30)
pyglet.clock.schedule_once(zmen_obrazek, 3)

pyglet.app.run()
