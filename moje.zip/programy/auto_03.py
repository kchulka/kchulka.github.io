#!/usr/bin/env python3
import pyglet, random
from pyglet.window import key

"""
verze 03

- pohyb obrázku nahoru a dolů
    smer_x, smer_y
    
    key.UP      - pohyb nahoru
    key.DOWN    - pohyb dolů

- vracení obrázku do okna, když 'vyjede' mimo rozměry okna
    window.width, window.height - rozměry okna aplikace
    auto.width, auto.height       - rozměry obrázku (spritu)

- pozadí
    přidán sprite s obrázkem pozadí
    vykreslovat ve funkci vykresli()

"""
def tik(t):
    auto.x = auto.x + v*t * smer_x
    auto.y = auto.y + v*t * smer_y

    # -- obrázek mimo okno aplikace --
    if auto.x > window.width:
        auto.x = -auto.width
    
    if auto.x+auto.width < 0:
        auto.x = window.width
    
    if auto.y > window.height:
        auto.y = -auto.height
    
    if auto.y+auto.height < 0:
        auto.y = window.height

def zpracuj_klavesu(klavesa, mod):
    global smer_x, smer_y, v
 
    if klavesa == key.RIGHT:
        smer_x = 1
        smer_y = 0
 
    elif klavesa == key.LEFT:
        smer_x = -1
        smer_y = 0
    
    elif klavesa == key.UP:
        smer_x = 0
        smer_y = 1
    
    elif klavesa == key.DOWN:
        smer_x = 0
        smer_y = -1
    
    elif klavesa == key.PLUS:
        v += v_delta
    
    elif klavesa == key.MINUS:        
        v -= v_delta    

def klik(x, y, tlacitko, mod):
    auto.x = x
    auto.y = y    

def vykresli():
    window.clear()
    pozadi.draw()
    auto.draw()

smer_x = 1
smer_y = 0
v = 20
v_delta = 10

window = pyglet.window.Window(width=1500, height=900)
auto = pyglet.sprite.Sprite(pyglet.image.load('auto1.png'))
pozadi = pyglet.sprite.Sprite(pyglet.image.load('bg6.png'))

window.push_handlers(
    on_key_press=zpracuj_klavesu,
    on_draw=vykresli,
    on_mouse_press=klik,
)

pyglet.clock.schedule_interval(tik, 1/30)
pyglet.app.run()
