#!/usr/bin/env python3
import pyglet
from pyglet.window import mouse
from pyglet.window import key



def tik(t):
    """ obsluha 'clock tick' - běh hodin """
    global v, pauza
    if pauza == True:
        print("pauza:", pauza)
    if pauza == False:
        had.x += v*t
        auto2.x -= auto2_v * t

        if smer_x != 0:
            auto3.x = auto3.x + auto3_v*t * smer_x
    
        if auto2.x > window.width:
            auto2.x = -auto2.width
        if auto2.x+auto2.width < 0:
            auto2.x = window.width
        
        if had.x > window.width-had.width:
            v = -abs(v)
        if had.x < 0:
            v = abs(v)

        if auto3.x > window.width:
            auto3.x = -auto2.width
        if auto3.x+auto2.width < 0:
            auto3.x = window.width


            
def klik(x, y, tlacitko, mod):
    """ obsluha 'on_mouse_press' - klik myší """
    if tlacitko == mouse.RIGHT:
        had.x = x
        had.y = y
    if tlacitko == mouse.LEFT:
        auto2.x = x
        auto2.y = y  
    if tlacitko == mouse.MIDDLE:
        auto3.x = x
        auto3.y = y

        
def vykresli():
    """ obsluha 'on_draw' - vykreslení celé scény """
    window.clear()
    bg.draw()
    auto3.draw()
    had.draw()
    auto2.draw()

def imgchange(t):
    global auto3, smer_x
    if pauza == False:
        print("Image change:", auto3.image)
        if smer_x == 1:
            auto3.image = obrazek_vpravo_2
        elif smer_x == -1:
            auto3.image = obrazek_vlevo_2
        pyglet.clock.schedule_once(imgchange2,casovanianimace/2)
    
def imgchange2(t):
    global auto3, smer_x
    if pauza == False:
        print("Image change:", auto3.image)
        if smer_x == 1:
            auto3.image = obrazek_vpravo
        elif smer_x == -1:
            auto3.image = obrazek_vlevo
        
def klavesnice(tlacitko, mod):
    """ ovladač 'on_mouse_press' - stisku klávesy """
    global smer_x, auto3_v, smer_vpravo, pauza
    print("pressed key:", tlacitko)

    
    if tlacitko == key.D:
        smer_x = 1
        auto3.image = obrazek_vpravo
    elif tlacitko == key.A:
        smer_x = -1
        auto3.image = obrazek_vlevo
    elif tlacitko == key.W:
            auto3_v = auto3_v + v_delta
    elif tlacitko == key.S:
            auto3_v = auto3_v - v_delta
    elif tlacitko == key.R:
        smer_x = 1
        auto3_v = 0
        auto3.image = obrazek_vpravo
        auto3.x = 500
        auto3.y = 200
        
    if tlacitko == key.P:
        pauza = True
        
def klavesnice2(tlacitko, dalsi):
    global pauza
    print("released key:", tlacitko)
    if tlacitko == key.P:
        pauza = False
# -- 'rychlost' posunu obrázku po scéně --
v = 50
auto2_v = 50
smer_x = 1
v_delta = 10
auto3_v = 0
pauza = False

casovanianimace = 1

obrazek_vpravo   = pyglet.image.load('auto2_vpravo.png')
obrazek_vlevo    = pyglet.image.load('auto2_vlevo.png')
obrazek_vpravo_2 = pyglet.image.load('auto2_vpravo_2.png')
obrazek_vlevo_2  = pyglet.image.load('auto2_vlevo_2.png')

# -- vytvoření objektu okna aplikace --
window = pyglet.window.Window(1280, 720, resizable=True)

# -- vytvoření 'sprite' - objektu obrázku --
obrazek_had = pyglet.image.load('Volodymyr_Zelensky.png') # Volodymyr_Zelensky
had = pyglet.sprite.Sprite(obrazek_had)

auto2 = pyglet.sprite.Sprite(pyglet.image.load('putin.png'))

bg = pyglet.sprite.Sprite(pyglet.image.load('bg-ukraine.jpg'))

auto3 = pyglet.sprite.Sprite(obrazek_vpravo, x=500, y=10)


#window.set_mouse_cursor(pyglet.window.ImageMouseCursor(pyglet.image.load('putin2.png')))


had.y = 300
auto2.y = 300
had.x = 200
auto2.x = 800  
# -- registrování oblužných funkcí k příslušným událostem --
window.push_handlers(
    on_draw=vykresli,
    on_mouse_press=klik,
    on_key_press=klavesnice,
    on_key_release=klavesnice2,
)

# -- registrace funkce pro obsluhu 'běhu času' --
pyglet.clock.schedule_interval(tik, 1/60)
pyglet.clock.schedule_interval(imgchange, casovanianimace)
# -- spuštění aplikace --
pyglet.app.run()

